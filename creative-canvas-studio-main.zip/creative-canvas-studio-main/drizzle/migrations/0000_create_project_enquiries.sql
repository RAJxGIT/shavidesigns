CREATE TABLE public.project_enquiries (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 created_at timestamptz NOT NULL DEFAULT now(),
 name text NOT NULL CHECK (char_length(btrim(name)) BETWEEN 2 AND 100),
 email text NOT NULL CHECK (char_length(email) <= 255 AND email ~ '^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$'),
 phone text NOT NULL DEFAULT '' CHECK (char_length(phone) <= 30 AND phone ~ '^[0-9+() .-]*$'),
 service text NOT NULL CHECK (service IN ('Poster design','Banner design','Standee design','Logo & branding','Social media design','Other design')),
 brief text NOT NULL CHECK (char_length(btrim(brief)) BETWEEN 10 AND 2000)
);
GRANT INSERT ON public.project_enquiries TO anon, authenticated;
GRANT ALL ON public.project_enquiries TO service_role;
ALTER TABLE public.project_enquiries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Visitors can submit enquiries" ON public.project_enquiries FOR INSERT TO anon, authenticated WITH CHECK (true);