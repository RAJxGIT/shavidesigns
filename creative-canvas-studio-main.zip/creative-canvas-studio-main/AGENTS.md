<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Application architecture
- Keep public studio pages as TanStack leaf routes and reuse studio sections from components, so navigation and page metadata stay independent.
- Validate enquiries with the shared Zod schema and database constraints; allow public insert only, so visitors cannot read other enquiries.
- Keep all studio visual values in the global CSS design system, so the presentation remains consistent across pages.
