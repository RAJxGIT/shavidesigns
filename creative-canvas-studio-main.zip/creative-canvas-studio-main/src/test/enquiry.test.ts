import { describe, it, expect } from 'vitest';
import { enquirySchema } from '@/lib/enquiry';
const valid = {name:'Alex Morgan',email:'alex@example.com',phone:'',service:'Poster design',brief:'A poster for an upcoming exhibition.'};
describe('project enquiry validation',()=>{
 it('accepts a project enquiry without an optional phone number',()=>{expect(enquirySchema.safeParse(valid).success).toBe(true);});
 it('rejects an invalid contact email',()=>{expect(enquirySchema.safeParse({...valid,email:'not-an-email'}).success).toBe(false);});
 it('rejects an unsupported service',()=>{expect(enquirySchema.safeParse({...valid,service:'unknown'}).success).toBe(false);});
 it('rejects a missing project requirement',()=>{expect(enquirySchema.safeParse({...valid,brief:''}).success).toBe(false);});
 it('rejects letters in phone numbers',()=>{expect(enquirySchema.safeParse({...valid,phone:'hello'}).success).toBe(false);});
});