import { createFileRoute } from '@tanstack/react-router';
import { Hero, ServicesSection, WorkSection, ProcessSection, ContactSection, studioMeta } from '@/components/studio';

export const Route = createFileRoute('/')({
  head: () => studioMeta('Graphic design, made to stand out', 'Forma Studio creates distinctive posters, banners, standees, logos, and social media designs. Tell us about your next project.'),
  component: Index,
});
function Index() { return <main><Hero/><ServicesSection/><WorkSection/><ProcessSection/><ContactSection/></main>; }
