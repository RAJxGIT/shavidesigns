import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, ServicesSection, ContactSection, studioMeta } from '@/components/studio';
export const Route = createFileRoute('/services')({ head: () => studioMeta('Design services', 'Explore poster, banner, standee, logo, branding, social media and custom graphic design services at Forma Studio.'), component: Services });
function Services(){return <main><PageIntro label="Made for your brand" title="Good design. Every format."/><ServicesSection/><ContactSection/></main>;}