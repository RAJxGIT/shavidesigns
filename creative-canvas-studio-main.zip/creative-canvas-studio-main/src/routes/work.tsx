import { createFileRoute } from '@tanstack/react-router';
import { PageIntro, WorkSection, ContactSection, studioMeta } from '@/components/studio';
export const Route = createFileRoute('/work')({ head: () => studioMeta('Creative work', 'Explore Forma Studio’s concept projects in poster design, brand identity, and social media design.'), component: Work });
function Work(){return <main><PageIntro label="A selection of creative explorations" title="Ideas made visible."/><WorkSection full/><ContactSection/></main>;}