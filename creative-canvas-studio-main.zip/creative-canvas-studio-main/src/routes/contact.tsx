import { createFileRoute } from '@tanstack/react-router';
import { ContactSection, studioMeta } from '@/components/studio';
import { services } from '@/lib/enquiry';
export const Route = createFileRoute('/contact')({
 validateSearch: (search: Record<string,unknown>): {service?:string | undefined} => ({service: services.find(s=>s===search['service'])}),
 head: () => studioMeta('Start your design project', 'Contact Forma Studio with your graphic design requirements. Send your project brief, contact details, and preferred design service.'),
 component: Contact,
});
function Contact(){const {service}=Route.useSearch();return <main className="pt-8"><ContactSection key={service} initialService={service}/></main>;}