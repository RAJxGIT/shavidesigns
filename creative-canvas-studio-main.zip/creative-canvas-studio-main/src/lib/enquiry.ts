import { z } from 'zod';

export const services = ['Poster design', 'Banner design', 'Standee design', 'Logo & branding', 'Social media design', 'Other design'] as const;
export const enquirySchema = z.object({
  name: z.string().trim().min(2, 'Please enter your name.').max(100),
  email: z.string().trim().email('Please enter a valid email address.').max(255),
  phone: z.string().trim().max(30).regex(/^[0-9+() .-]*$/, 'Please enter a valid phone number.'),
  service: z.enum(services, { errorMap: () => ({ message: 'Please choose a service.' }) }),
  brief: z.string().trim().min(10, 'Tell us a little more about your project (at least 10 characters).').max(2000),
});